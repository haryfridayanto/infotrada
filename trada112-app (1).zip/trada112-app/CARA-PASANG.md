# Cara Memasang "Data Berita TRADA 112" di HP

Aplikasi ini berbentuk **PWA** — bisa dipasang ke layar utama Android/iPhone,
punya ikon sendiri, buka layar penuh tanpa address bar, dan **jalan offline**.

---

## Langkah 1 — Unggah folder ini ke internet (sekali saja, ±3 menit)

Aplikasi perlu alamat HTTPS agar bisa dipasang. Pilih **salah satu** cara gratis:

### Cara A — Netlify Drop (paling cepat, tanpa akun)
1. Buka **https://app.netlify.com/drop** di komputer.
2. Seret seluruh folder `trada112-app` ke halaman itu.
3. Tunggu beberapa detik → muncul alamat seperti
   `https://nama-acak-123.netlify.app`
4. Salin alamat tersebut. **Selesai.**

> Daftar akun gratis (opsional) agar alamatnya permanen dan bisa diganti
> jadi nama sendiri, misalnya `trada112.netlify.app`.

### Cara B — GitHub Pages
1. Buat repository baru di GitHub, misalnya `trada112`.
2. Unggah semua isi folder ini (index.html, sw.js, manifest, folder icons).
3. Masuk **Settings → Pages → Source: Branch `main` / root** → Save.
4. Alamat aplikasi: `https://<username>.github.io/trada112/`

### Cara C — Google Drive / hosting kantor
Bisa juga diletakkan di hosting mana pun milik Trada
(misalnya `https://trada.co.id/db112/`), asalkan HTTPS.
Google Drive **tidak bisa** dipakai karena tidak menyajikan HTML secara langsung.

---

## Langkah 2 — Pasang di HP

### Android (Chrome)
1. Buka alamat aplikasi di Chrome.
2. Akan muncul kotak **"Pasang ke layar utama"** di dalam aplikasi → ketuk **Pasang**.
   *Atau:* menu ⋮ di Chrome → **Tambahkan ke Layar utama / Instal aplikasi**.
3. Ikon TRADA 112 muncul di layar utama seperti aplikasi biasa.

### iPhone (Safari)
1. Buka alamat aplikasi di **Safari** (harus Safari, bukan Chrome).
2. Ketuk tombol **Bagikan** (kotak dengan panah ke atas).
3. Pilih **Tambah ke Layar Utama** → **Tambah**.

---

## Langkah 3 — Menambah berita baru

Ketuk tombol merah **＋** di kanan bawah, tempel URL, simpan.
Kolom lain boleh dikosongkan. Data tersimpan di HP dan tetap ada
walau aplikasi ditutup atau sedang offline.

**Penting:** data tersimpan per-perangkat. Agar aman:
- Menu ☰ → **Ekspor cadangan** → simpan file JSON secara berkala.
- Di HP lain: Menu ☰ → **Impor cadangan** → pilih file JSON tersebut.
  Entri yang sudah ada tidak akan terduplikasi.

---

## Memperbarui isi aplikasi

Ketika ada versi baru (misalnya arsip bertambah dari hasil riset):
1. Ganti file `index.html` di hosting dengan yang baru.
2. Buka `sw.js`, naikkan versinya: `trada112-v1` → `trada112-v2`, simpan.
3. Di HP, tutup lalu buka lagi aplikasinya — versi baru termuat otomatis.
   Entri yang Anda tambahkan sendiri **tidak akan hilang**.

---

## Kalau benar-benar butuh file APK

Setelah aplikasi online (Langkah 1), APK bisa dibuat gratis tanpa coding:

1. Buka **https://www.pwabuilder.com**
2. Masukkan alamat aplikasi Anda → **Start**.
3. Pilih **Android → Generate Package**.
4. Unduh hasilnya. Di dalamnya ada file `.apk` untuk dipasang langsung
   (aktifkan "Instal aplikasi tidak dikenal" di Android) dan `.aab`
   bila suatu saat mau diunggah ke Google Play Store.

Catatan: dengan APK, setiap pembaruan isi harus install ulang.
Versi PWA memperbarui dirinya sendiri — itulah kenapa saya sarankan PWA.

---

## Isi folder

| Berkas | Fungsi |
|---|---|
| `index.html` | Aplikasi utama beserta seluruh arsip berita |
| `manifest.webmanifest` | Identitas aplikasi (nama, ikon, warna) |
| `sw.js` | Membuat aplikasi jalan offline |
| `icons/` | Ikon aplikasi 192px, 512px, dan maskable |
| `CARA-PASANG.md` | Panduan ini |

Arsip bawaan: **28 entri** (15 berfoto asli dari sumber, sisanya tangkapan layar otomatis) berita dan kegiatan
PT Trada Telekom Indonesia & Hary Fridayanto.
