/* TRADA 112 — Service Worker
   Naikkan angka VERSION setiap kali isi aplikasi diperbarui,
   agar HP mengunduh versi terbaru. */
const VERSION = 'trada112-v4';
const IMG_CACHE = 'trada112-img-v1';
const ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(VERSION)
      .then(c => c.addAll(ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== VERSION && k !== IMG_CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

/* Strategi: network-first untuk halaman (agar update cepat terlihat),
   cache-first untuk aset statis. Offline tetap jalan. */
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;

  /* Gambar: simpan permanen setelah sekali termuat, agar tetap tampil offline. */
  if (req.destination === 'image') {
    e.respondWith(
      caches.open(IMG_CACHE).then(c =>
        c.match(req).then(hit => {
          if (hit) return hit;
          return fetch(req).then(res => {
            try { c.put(req, res.clone()); } catch (_) {}
            return res;
          }).catch(() => hit || new Response('', { status: 404 }));
        })
      )
    );
    return;
  }

  const isDoc = req.mode === 'navigate' || (req.headers.get('accept') || '').includes('text/html');

  if (isDoc) {
    e.respondWith(
      fetch(req)
        .then(res => {
          const copy = res.clone();
          caches.open(VERSION).then(c => c.put(req, copy));
          return res;
        })
        .catch(() => caches.match(req).then(r => r || caches.match('./index.html')))
    );
    return;
  }

  e.respondWith(
    caches.match(req).then(cached => cached || fetch(req).then(res => {
      const copy = res.clone();
      caches.open(VERSION).then(c => c.put(req, copy));
      return res;
    }).catch(() => cached))
  );
});
