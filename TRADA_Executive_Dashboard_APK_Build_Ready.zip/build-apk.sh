#!/usr/bin/env bash
set -euo pipefail
if ! command -v java >/dev/null; then echo 'Java 17+ required'; exit 1; fi
if [ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]; then echo 'Set ANDROID_HOME to Android SDK'; exit 1; fi
if [ -x ./gradlew ]; then RUN=./gradlew; elif command -v gradle >/dev/null; then RUN=gradle; else echo 'Gradle 8.x required; open project in Android Studio and build APK'; exit 1; fi
$RUN --no-daemon :app:assembleDebug
printf 'APK: %s\n' "$PWD/app/build/outputs/apk/debug/app-debug.apk"
