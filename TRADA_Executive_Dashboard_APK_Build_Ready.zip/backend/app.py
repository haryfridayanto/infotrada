"""Fail-closed backend. Never overwrite Drive unless a complete, tested builder is installed."""
import os, json, hashlib, subprocess
from pathlib import Path
from fastapi import FastAPI, HTTPException, Header
from fastapi.responses import FileResponse
from google.oauth2 import service_account
from googleapiclient.discovery import build

app=FastAPI(title="TRADA sync gateway")

@app.get("/api/health")
def health():
 return {"status":"ok","publication":"disabled_until_verified"}
SOURCE_IDS=["113-y-H7AIdoFQZAx4h66Xy3A6QAzet5Y5NmiDZvo0zI","1aLbu7dO6v1MndwDkDbU868XheqS3SOsKURb_oD0BPqY"]
TARGET="1PL9e8SBy9fXQNXfBQ-FOHMb000bO-r9p"
BASE=Path(__file__).resolve().parent
ARTIFACT=BASE/'validated_dashboard.html'

def services():
 creds=service_account.Credentials.from_service_account_file(os.environ['GOOGLE_APPLICATION_CREDENTIALS'],scopes=['https://www.googleapis.com/auth/drive','https://www.googleapis.com/auth/spreadsheets.readonly'])
 return build('drive','v3',credentials=creds,cache_discovery=False),build('sheets','v4',credentials=creds,cache_discovery=False)

def meta(drive,fid):
 return drive.files().get(fileId=fid,fields='id,name,mimeType,modifiedTime,size,md5Checksum',supportsAllDrives=True).execute()

def verify(html):
 if len(html)<10000: raise ValueError('HTML too short')
 for key in ['INFOGRAFIS','DATABASE_TRADA','DATAAREA','INVOICE','DB_PENGELUARAN','Komdigi','Wallboard']:
  if key.lower() not in html.lower(): raise ValueError('Missing '+key)
 # The production builder must also run JS + functional tests before publishing.

@app.post('/api/sync')
def sync(authorization: str|None=Header(default=None)):
 token=os.environ.get('SYNC_API_TOKEN')
 if not token or authorization != 'Bearer '+token: raise HTTPException(401,'Unauthorized')
 drive,sheets=services()
 before=[meta(drive,f) for f in SOURCE_IDS]; target=meta(drive,TARGET)
 if all(x['modifiedTime']<=target['modifiedTime'] for x in before):return {'status':'no_change'}
 # Read all five source tabs, but do not leak data or overwrite original.
 tabmap={SOURCE_IDS[0]:['DATABASE','DATAAREA','DB_PENGELUARAN','INVOICE']}
 info=sheets.spreadsheets().get(spreadsheetId=SOURCE_IDS[1],fields='sheets(properties(title))').execute()
 titles=[x['properties']['title'] for x in info.get('sheets',[])]
 preferred=os.environ.get('KOMDIGI_TAB')
 if not preferred:
  preferred=next((t for t in ['Data Pemda 112 - Update','DATABASE','Database','Sheet1'] if t in titles),None)
 if not preferred and len(titles)==1: preferred=titles[0]
 if preferred not in titles: raise HTTPException(503,'Komdigi tab missing or ambiguous')
 tabmap[SOURCE_IDS[1]]=[preferred]
 rows={}
 for fid,tabs in tabmap.items():
  for tab in tabs:
   try: rows[('Komdigi' if fid==SOURCE_IDS[1] else tab)]=sheets.spreadsheets().values().get(spreadsheetId=fid,range="'"+tab.replace("'","''")+"'!A:ZZ").execute().get('values',[])
   except Exception as e: raise HTTPException(503,f'Source tab unavailable: {tab}') from e
 # A builder is intentionally required. Blind JSON injection would break existing filters/charts.
 # Install a reviewed builder.py with build_dashboard(rows, old_html)->str, and full regression tests.
 try:
  from builder import build_dashboard
 except ImportError:
  return {'status':'builder_required','message':'Sources changed, but no verified HTML reconstruction installed; original preserved.'}
 old=ARTIFACT.read_text('utf8') if ARTIFACT.exists() else (BASE/'seed_dashboard.html').read_text('utf8')
 candidate=build_dashboard(rows,old)
 verify(candidate)
 from validate_dashboard import validate
 candidate_path=BASE/'candidate.html'
 candidate_path.write_text(candidate,encoding='utf8')
 validate(candidate_path)
 after=[meta(drive,f) for f in SOURCE_IDS]
 if any(a['modifiedTime']!=b['modifiedTime'] for a,b in zip(before,after)):
  raise HTTPException(409,'Sources changed during build; retry')
 tmp=BASE/'candidate.html'
 subprocess.run(['node','--check',str(BASE/'extract_js.js')],check=True,capture_output=True) if (BASE/'extract_js.js').exists() else None
 # Fail closed: never auto-upload to Drive without integration regression tests and a reviewed publisher.
 return {'status':'review_required','message':'Candidate generated; publish only after regression validation and source recheck.'}

@app.get('/api/dashboard')
def dashboard(authorization: str|None=Header(default=None)):
 token=os.environ.get('SYNC_API_TOKEN')
 if not token or authorization!='Bearer '+token:raise HTTPException(401,'Unauthorized')
 if not ARTIFACT.exists():raise HTTPException(404,'No validated artifact')
 return FileResponse(ARTIFACT,media_type='text/html')
