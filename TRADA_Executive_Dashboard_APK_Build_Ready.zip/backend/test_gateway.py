import unittest
from unittest.mock import patch, MagicMock
import os
from fastapi import HTTPException
import app

class GatewayTests(unittest.TestCase):
 def test_unauthorized_without_token(self):
  with patch.dict(os.environ, {}, clear=True):
   with self.assertRaises(HTTPException) as ctx: app.sync(None)
   self.assertEqual(ctx.exception.status_code,401)
 def test_no_change_never_reads_sheets_or_publishes(self):
  drive=MagicMock(); sheets=MagicMock()
  with patch.dict(os.environ, {"SYNC_API_TOKEN":"secret"}), patch.object(app,"services",return_value=(drive,sheets)), patch.object(app,"meta",side_effect=[{"modifiedTime":"2026-10-01T00:00:00Z"},{"modifiedTime":"2026-10-01T00:00:00Z"},{"modifiedTime":"2026-10-02T00:00:00Z"}]):
   self.assertEqual(app.sync("Bearer secret"),{"status":"no_change"})
   sheets.assert_not_called() if callable(sheets) else None
   drive.files().update.assert_not_called()
 def test_incomplete_dashboard_rejected(self):
  with self.assertRaises(ValueError): app.verify("<html></html>")

if __name__=="__main__": unittest.main()
