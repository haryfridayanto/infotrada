import unittest
from reconcile import normalize, reconcile

class ReconcileTests(unittest.TestCase):
    def test_province_and_city_both_required(self):
        master=[{'province':'Sulawesi Tenggara','city':'Kota Kendari'},
                {'province':'Sulawesi Selatan','city':'Kota Kendari'}]
        source=[{'province':'Sulawesi Tenggara','city':'Kendari','provider':'A'}]
        result=reconcile(master,source)
        self.assertEqual(result[0]['komdigi_provider'],'A')
        self.assertEqual(result[1]['reconciliation'],'CEK PROVINSI')
    def test_free_is_missing_not_official(self):
        row=reconcile([{'province':'Jawa Barat','city':'Depok'}],[])[0]
        self.assertEqual(row['komdigi_provider'],'FREE')
        self.assertEqual(row['komdigi_origin'],'FREE • BELUM TERCATAT KOMDIGI')
    def test_duplicate_ambiguous(self):
        m=[{'province':'Bali','city':'Denpasar'}]
        k=[{'province':'Bali','city':'Denpasar','provider':'A'}, {'province':'Bali','city':'Denpasar','provider':'B'}]
        self.assertEqual(reconcile(m,k)[0]['reconciliation'],'CEK PROVINSI')
    def test_normalization(self):
        self.assertEqual(normalize('KAB. BONE'),normalize('Kabupaten Bone'))

if __name__=='__main__': unittest.main()
