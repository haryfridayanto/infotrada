"""Conservative HTML syntax gate; not a substitute for functional regression tests."""
import pathlib
import re
import subprocess
import sys
import tempfile

REQUIRED = ('INFOGRAFIS', 'DATABASE_TRADA', 'DATAAREA', 'INVOICE', 'DB_PENGELUARAN', 'Komdigi', 'Wallboard')

def validate(path):
    html = pathlib.Path(path).read_text(encoding='utf-8')
    if len(html) < 10000:
        raise ValueError('Dashboard too small')
    for name in REQUIRED:
        if name.casefold() not in html.casefold():
            raise ValueError('Missing ' + name)
    if re.search(r'<script\b[^>]*\bsrc\s*=\s*[\'\"]?https?://', html, re.I):
        raise ValueError('External scripts forbidden')
    scripts = re.findall(r'<script\b[^>]*>(.*?)</script\s*>', html, re.I | re.S)
    if not scripts:
        raise ValueError('No inline scripts')
    for index, script in enumerate(scripts):
        if not script.strip():
            continue
        with tempfile.TemporaryDirectory() as d:
            file = pathlib.Path(d) / f'inline-{index}.js'
            file.write_text(script, encoding='utf-8')
            result = subprocess.run(['node', '--check', str(file)], capture_output=True, text=True)
            if result.returncode:
                raise ValueError(f'JavaScript {index} failed: {result.stderr}')
    return len(scripts)

if __name__ == '__main__':
    print('PASS inline scripts:', validate(sys.argv[1]))
