"""Deterministic province+city reconciliation. FREE means missing from source, not provider absence."""
import re
import unicodedata


def normalize(value):
    value = unicodedata.normalize('NFKC', str(value or '')).casefold()
    value = re.sub(r'\b(kabupaten|kab\.?|kota|administrasi)\b', '', value)
    return re.sub(r'[^a-z0-9]+', ' ', value).strip()


def reconcile(master, komdigi):
    """Input dictionaries with province, city and provider. Return one row per master region.

    Ambiguous city matches in other provinces are flagged for manual review,
    never marked FREE. Duplicate source keys are also flagged.
    """
    exact = {}
    city_index = {}
    for item in komdigi:
        key = (normalize(item.get('province')), normalize(item.get('city')))
        if not all(key):
            continue
        exact.setdefault(key, []).append(item)
        city_index.setdefault(key[1], []).append(item)
    result = []
    for region in master:
        key = (normalize(region.get('province')), normalize(region.get('city')))
        matched = exact.get(key, [])
        row = dict(region)
        if len(matched) == 1:
            row.update(komdigi_provider=matched[0].get('provider') or '(Belum diisi)',
                       komdigi_origin='KOMDIGI', reconciliation='MATCH')
        elif len(matched) > 1 or city_index.get(key[1]):
            row.update(komdigi_provider='CEK PROVINSI', komdigi_origin='PERLU REKONSILIASI',
                       reconciliation='CEK PROVINSI')
        else:
            row.update(komdigi_provider='FREE', komdigi_origin='FREE • BELUM TERCATAT KOMDIGI',
                       reconciliation='BELUM TERCATAT')
        result.append(row)
    return result
