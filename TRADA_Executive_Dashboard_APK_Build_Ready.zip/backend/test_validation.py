import tempfile
import unittest
from pathlib import Path
from validate_dashboard import validate

class ValidationTests(unittest.TestCase):
    def test_bundled_dashboard(self):
        self.assertGreaterEqual(validate(Path(__file__).with_name('seed_dashboard.html')), 1)
    def test_missing_sections(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'bad.html'
            path.write_text('<html><script>let a=1</script></html>')
            with self.assertRaises(ValueError):
                validate(path)
    def test_invalid_js(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'bad.html'
            path.write_text(' '.join(('INFOGRAFIS','DATABASE_TRADA','DATAAREA','INVOICE','DB_PENGELUARAN','Komdigi','Wallboard')) + ' '*12000 + '<script>const = ;</script>')
            with self.assertRaisesRegex(ValueError, 'JavaScript'):
                validate(path)

if __name__ == '__main__':
    unittest.main()
