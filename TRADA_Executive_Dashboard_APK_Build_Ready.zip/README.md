# TRADA Executive Dashboard — Android + Sync Gateway

## Isi proyek
- `app/`: Android Kotlin WebView, dashboard HTML offline bawaan, tombol **UPDATE DATA NOW**.
- `backend/`: FastAPI gateway Google Sheets/Drive, memeriksa modifiedTime, membaca 5 tab dan **fail-closed**.
- Dashboard HTML snapshot 8 Oktober 2026 sebagai aset offline.

## Build Android
1. Buka folder ini di Android Studio (JDK 17, Android SDK 35).
2. Ubah `BACKEND_URL` di `app/build.gradle.kts` ke alamat HTTPS backend Anda.
3. Build > Build APK(s). APK debug akan ada di `app/build/outputs/apk/debug/`.

## Backend
1. Buat service account Google Cloud, aktifkan Drive API + Sheets API.
2. Berikan akses baca ke kedua Google Sheets dan akses yang diperlukan ke HTML utama kepada service account.
3. Simpan kunci service account **hanya di server**, jangan pernah di APK.
4. `pip install -r backend/requirements.txt` lalu `GOOGLE_APPLICATION_CREDENTIALS=/secure/key.json SYNC_API_TOKEN=... uvicorn app:app --host 0.0.0.0 --port 8000`.
5. Pasang reverse proxy HTTPS, login/OIDC, rate limit, audit log. **Aplikasi belum mengirim bearer token**; integrasikan autentikasi pengguna sebelum production.

## Status integrasi dan batasan penting
- Proyek ini **source code**, bukan APK terkompilasi; Android SDK/Gradle tidak tersedia di lingkungan pembuatan.
- Tombol dan tampilan offline sudah dibuat, tetapi sinkronisasi otomatis penuh **belum operasional**.
- Backend mengecek timestamp dan membaca 5 tab, tetapi builder yang merekonstruksi seluruh HTML + tes regresi + publisher Drive **belum disertakan**. Bila sumber berubah, endpoint mengembalikan `builder_required` dan **tidak mengubah file utama**.
- Nama tab Komdigi perlu dikonfirmasi dari metadata Sheets, lalu sesuaikan `tabmap` bila berbeda.
- Jangan menganggap nilai `FREE` sebagai konfirmasi penyedia resmi.
- Tidak ada kredensial, nomor PIC, atau token Google tertanam di aplikasi.
- Sebelum rilis: implementasikan OIDC atau session auth, builder lengkap, tes filter/grafik/Kendari 2025–2026/FREE, validasi sumber ulang, serta update byte Drive pada ID yang sama secara atomik/terkendali.

## Tahap lanjutan — 8 Oktober 2026
- Form token sementara di aplikasi Android: token hanya berada di memori selama Activity hidup, tidak disimpan ke disk/APK. Backend memerlukan `SYNC_API_TOKEN` yang sama.
- HTTP ditolak oleh aplikasi; konfigurasi URL harus HTTPS.
- Respons sinkronisasi diparse sebagai JSON dan status non-2xx ditampilkan sebagai kegagalan.
- Tes backend: `cd backend && python -m unittest test_gateway.py` (instal requirements terlebih dahulu).
- **Belum production-ready:** endpoint `/api/sync` tetap fail-closed dan tidak mengunggah HTML tanpa builder terverifikasi, pengujian JS/UI, serta recheck timestamp sumber. Token statis ini hanya tahap prototipe; gunakan OIDC/SSO, otorisasi per pengguna, dan audit log sebelum distribusi.
- Tidak ada kunci Google/service-account dalam APK.

## V4 changes
- Health endpoint `/api/health` to distinguish gateway availability from successful synchronization.
- Dynamically discover Komdigi worksheet title; `KOMDIGI_TAB` overrides ambiguous selection.
- Keep Komdigi rows under a distinct key to avoid collisions with master DATABASE.
- Recheck source modifiedTime after HTML candidate construction; fail with HTTP 409 on race.
- Publisher remains intentionally disabled until full reconstruction and regression tests are supplied.
- Google Drive target ID is never overwritten by this prototype.
\n## V5\nBundled prior offline dashboard as backend seed; added inline JavaScript syntax validation and transactional Android cache replacement. Publication remains disabled; a reviewed full builder, live backend and Android compilation are still required.\n
## V7 reconciliation engine (tested independently)
`backend/reconcile.py` provides a province + kabupaten/kota join with
explicit FREE/CEK PROVINSI flags. This is a **building block**, not yet wired
into a complete five-source dashboard builder. No Drive update is performed.
Run `cd backend && python -m unittest test_reconcile.py test_validation.py`.
