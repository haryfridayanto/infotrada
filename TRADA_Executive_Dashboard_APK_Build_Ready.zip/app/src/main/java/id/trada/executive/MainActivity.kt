package id.trada.executive

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.EditText
import android.text.InputType
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.File
import java.security.MessageDigest

class MainActivity : Activity() {
 private lateinit var browser: WebView
 private lateinit var status: TextView
 private lateinit var tokenInput: EditText
 private val cacheName = "dashboard.html"
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(12,12,12,8) }
  val button=Button(this).apply { text="⟳ UPDATE DATA NOW" }
  tokenInput=EditText(this).apply { hint="Token akses backend (tidak disimpan)"; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setSingleLine(true) }
  status=TextView(this).apply { text="Dashboard lokal • siap digunakan"; setPadding(6,4,6,10) }
  browser=WebView(this).apply {
   settings.javaScriptEnabled=true
   settings.domStorageEnabled=true
   settings.allowFileAccess=true
   settings.allowFileAccessFromFileURLs=false
   settings.allowUniversalAccessFromFileURLs=false
   webViewClient=WebViewClient(); webChromeClient=WebChromeClient()
  }
  root.addView(tokenInput); root.addView(button); root.addView(status); root.addView(browser,LinearLayout.LayoutParams(-1,0,1f))
  setContentView(root); showDashboard()
  button.setOnClickListener { button.isEnabled=false; status.text="Memeriksa sumber dan versi dashboard…";
   val token=tokenInput.text.toString().trim()
   Thread { try { sync(token) } catch(e:Exception) { runOnUiThread { status.text="Gagal sinkronisasi: ${e.message}" } }
    finally { runOnUiThread { button.isEnabled=true } } }.start()
  }
 }
 private fun showDashboard() {
  val cached=File(filesDir,cacheName)
  if(cached.exists()) browser.loadUrl("file://${cached.absolutePath}")
  else browser.loadUrl("file:///android_asset/dashboard.html")
 }
 private fun sync(token:String) {
  require(token.isNotBlank()) { "Masukkan token akses backend" }
  val base=BuildConfig.BACKEND_URL.trimEnd('/')
  if(!base.startsWith("https://") || base.contains("YOUR-BACKEND")) throw IllegalStateException("Alamat backend belum dikonfigurasi")
  // The backend must enforce user authentication; no service-account key is stored in the APK.
  val c=(URL("$base/api/sync").openConnection() as HttpURLConnection).apply {
   requestMethod="POST"; connectTimeout=20000; readTimeout=120000; doOutput=true
   setRequestProperty("Content-Type","application/json");setRequestProperty("Authorization","Bearer $token")
  }
  c.outputStream.use { it.write("{}".toByteArray()) }
  val code=c.responseCode
  val response=(if(code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }; c.disconnect()
  if(code !in 200..299) throw IllegalStateException("Backend HTTP $code")
  val syncStatus=JSONObject(response).optString("status")
  // Only download a server-validated artifact; never replace local cache on check-only response.
  if(syncStatus != "updated") {
   runOnUiThread { status.text=if(syncStatus=="no_change") "Tidak ada perubahan sumber" else "Belum diperbarui: backend memerlukan builder/validasi" }; return
  }
  val dl=(URL("$base/api/dashboard").openConnection() as HttpURLConnection).apply { connectTimeout=20000;readTimeout=120000;setRequestProperty("Authorization","Bearer $token") }
  if(dl.responseCode != 200) { dl.disconnect(); throw IllegalStateException("Dashboard HTTP error") }
  val bytes=dl.inputStream.use { it.readBytes() }; dl.disconnect()
  val html=bytes.toString(Charsets.UTF_8)
  require(bytes.size>10000 && html.contains("INFOGRAFIS") && html.contains("DATABASE_TRADA")) { "Dashboard tidak lengkap" }
  val tmp=File(filesDir,"dashboard.tmp");tmp.writeBytes(bytes)
  val cache=File(filesDir,cacheName)
  val backup=File(filesDir,"dashboard.bak")
  if(backup.exists()) backup.delete()
  if(cache.exists() && !cache.renameTo(backup)) throw IllegalStateException("Cache backup failed")
  if(!tmp.renameTo(cache)) {
   if(backup.exists()) backup.renameTo(cache)
   throw IllegalStateException("Gagal menyimpan cache")
  }
  backup.delete()
  runOnUiThread { status.text="Dashboard berhasil diperbarui";showDashboard() }
 }
}
