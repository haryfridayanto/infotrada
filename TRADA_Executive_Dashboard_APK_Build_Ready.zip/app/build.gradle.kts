plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "id.trada.executive"; compileSdk = 35
 defaultConfig { applicationId = "id.trada.executive"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0"; buildConfigField("String", "BACKEND_URL", "\"https://YOUR-BACKEND.example.com\"") }
 buildFeatures { buildConfig = true }
}
