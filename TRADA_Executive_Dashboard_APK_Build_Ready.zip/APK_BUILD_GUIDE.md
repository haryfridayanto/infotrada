# Build APK Android — TRADA Executive Dashboard

## Cara paling mudah tanpa Android Studio
1. Buat repository GitHub **private** dan unggah seluruh isi folder proyek ini ke root repository (termasuk `.github/workflows/build-apk.yml`).
2. Di GitHub pilih **Actions → Build TRADA Android APK → Run workflow**.
3. Setelah build berhasil, buka hasil run → **Artifacts → TRADA-Executive-Dashboard-debug-apk**.
4. Ekstrak ZIP artifact dan instal `app-debug.apk` di perangkat Android (izin pemasangan dari sumber tersebut mungkin diperlukan).

## Batasan penting
- APK debug ini menampilkan dashboard **snapshot offline**; bukan versi operasional yang otomatis memperbarui Google Sheets/Drive.
- Tombol UPDATE DATA NOW belum dapat digunakan sebelum URL HTTPS backend diganti dari placeholder dan backend sinkronisasi lima sumber diselesaikan, diuji, serta di-deploy.
- Untuk backend produksi, gunakan login OIDC/SSO, jangan mendistribusikan token Google atau service account di APK.
- Workflow belum dijalankan di GitHub dari lingkungan ini, jadi keberhasilan kompilasi Android belum terverifikasi.
- APK debug tidak untuk distribusi produksi; gunakan signing release dan uji keamanan sebelum distribusi.
