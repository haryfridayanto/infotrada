# APK build and production readiness

This is an Android Studio source project, **not** a compiled APK.

## Build APK
1. Install Android Studio, Android SDK Platform 35, Build Tools 35, JDK 17.
2. Open this directory as a Gradle project. Allow Android Studio to sync dependencies.
3. Choose Build > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`.
4. Transfer the debug APK to your Android phone and install it after reviewing the app permissions.

## Operational limits
- The Android app bundles an offline dashboard and has an UPDATE DATA NOW button.
- `BACKEND_URL` in `app/build.gradle.kts` is currently a placeholder; configure a real HTTPS endpoint and rebuild.
- A Google service account and deployed backend are not configured.
- Backend deliberately does not overwrite the original Google Drive HTML. A tested dashboard reconstruction and publisher are missing.
- Consequently, the button is **not yet a functioning live synchronization feature**.
- Never embed service-account credentials or API tokens into the APK.

Do not claim that this package contains an APK or that live updates are working.
